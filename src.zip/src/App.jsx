import Home from "./pages/Home";
import { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Explore from "./pages/Explore";
import Author from "./pages/Author";
import ItemDetails from "./pages/ItemDetails";
import Nav from "./components/Nav";
import Footer from "./components/Footer";

function App() {
  const [id, setId] = useState(null);

  useEffect(() => {
    console.log("ID changed:", id);
    setId(getNftId() || null);
  }, [id])

  function getNftId(id) {
    return id;
  }

  return (
    <>
      <link rel="stylesheet" href="/node_modules/owl.carousel/dist/assets/owl.carousel.min.css" />
    <Router>
      <Nav />
      <Routes>
        <Route path="/" element={<Home getNftId={getNftId} />} />
        <Route path="/explore" element={<Explore />} />
        <Route path="/author" element={<Author />} />
        <Route path={`/item-details/${id}`} element={<ItemDetails />} />
      </Routes>
      <Footer />
    </Router>
    <script src="/node_modules/jquery/dist/jquery.js"></script>
<script src="/node_modules/owl.carousel/dist/owl.carousel.min.js"></script>
    </>
  );
}

export default App;
