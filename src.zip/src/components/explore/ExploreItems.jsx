import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const ExploreItems = () => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const showPlaceholders = true;

  const [now, setNow] = useState(new Date().getTime());
  
    useEffect(() => {
      const interval = setInterval(() => {
        setNow(new Date().getTime());
      }, 1000);
      return () => clearInterval(interval);
    }, []);
  
    const calculateCountdown = (expiryDate, now) => {
      const expiry = new Date(expiryDate).getTime();
      const difference = expiry - now;
      if (difference <= 0) return "Expired";
      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);
      return `${days}d ${hours}h ${minutes}m ${seconds}s`;
    };

  useEffect(() => {
  let active = true;

  axios
    .get("https://us-central1-nft-cloud-functions.cloudfunctions.net/explore")
    .then(({ data }) => {
      if (active) {
        setItems(data);
      }
    })
    .catch((error) => {
      console.error("Failed to fetch explore items:", error);
    })
    .finally(() => {
      if (active) {
        setLoading(false);
      }
    });

  return () => {
    active = false;
  };
}, []);

  return (
    <>
      <div>
        <select id="filter-items" defaultValue="">
          <option value="">Default</option>
          <option value="price_low_to_high">Price, Low to High</option>
          <option value="price_high_to_low">Price, High to Low</option>
          <option value="likes_high_to_low">Most liked</option>
        </select>
      </div>
      {!showPlaceholders ? (items.map((item, index) => (
        <div
          key={index}
          className="d-item col-lg-3 col-md-6 col-sm-6 col-xs-12"
          style={{ display: "block", backgroundSize: "cover" }}
        >
          <div className="nft__item">
            <div className="author_list_pp">
              <Link
                to="/author"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
              >
                <img className="lazy" src={item?.authorImage} alt="" />
                <i className="fa fa-check"></i>
              </Link>
            </div>
            {item.expiryDate && <div className="de_countdown">{calculateCountdown(item?.expiryDate, now)}</div>}

            <div className="nft__item_wrap">
              <div className="nft__item_extra">
                <div className="nft__item_buttons">
                  <button>Buy Now</button>
                  <div className="nft__item_share">
                    <h4>Share</h4>
                    <a href="" target="_blank" rel="noreferrer">
                      <i className="fa fa-facebook fa-lg"></i>
                    </a>
                    <a href="" target="_blank" rel="noreferrer">
                      <i className="fa fa-twitter fa-lg"></i>
                    </a>
                    <a href="">
                      <i className="fa fa-envelope fa-lg"></i>
                    </a>
                  </div>
                </div>
              </div>
              <Link to="/item-details">
                <img src={item?.nftImage} className="lazy nft__item_preview" alt="" />
              </Link>
            </div>
            <div className="nft__item_info">
              <Link to="/item-details">
                <h4>{item?.title}</h4>
              </Link>
              <div className="nft__item_price">{item?.price} ETH</div>
              <div className="nft__item_like">
                <i className="fa fa-heart"></i>
                <span>{item?.likes}</span>
              </div>
            </div>
          </div>
        </div>
      )))
      : Array.from({ length: 8 }, (_, index) => (
          <div className="d-item col-lg-3 col-md-6 col-sm-6 col-xs-12" key={index}>
                <div className="nft__item skeleton-card">
                  <div className="author_list_pp">
                    <div className="skeleton skeleton-image"></div>
                  </div>

                  <div className="nft__item_wrap">
                    <div className="skeleton skeleton-avatar"></div>
                    <i className="fa fa-check"></i>
                  </div>

                                    <div className="nft__item_info">
                    <div className="skeleton skeleton-title"></div>
                    <div className="skeleton skeleton-subtitle"></div>
                  </div>
                </div>
              </div>
            ))
          }

          <div className="col-md-12 text-center">
            <Link to="" id="loadmore" className="btn-main lead">
              Load more
            </Link>
          </div>
        </>
      );
};

export default ExploreItems;